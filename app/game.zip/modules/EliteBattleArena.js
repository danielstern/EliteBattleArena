angular.module("EliteBattleArena", [
    'EliteBattleArena.AI',
    'EliteBattleArena.Actor',
    'EliteBattleArena.Battle',
    'EliteBattleArena.Game',
    'EliteBattleArena.Status',
    'EliteBattleArena.Dungeon',
    'EliteBattleArena.Helpers'])

