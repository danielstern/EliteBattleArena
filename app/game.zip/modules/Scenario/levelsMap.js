angular.module("EliteBattleArena.Scenario")


.service("levelsMap", function() {
    return {
        1: {
        	url:"partial/floors/floor-1.html",
        },
    }
})
