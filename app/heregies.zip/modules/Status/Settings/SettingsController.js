angular.module("EliteBattleArena.Status")

.controller("SettingsController", function($scope) {
    
})
