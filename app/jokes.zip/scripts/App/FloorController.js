angular.module("EliteBattleArena.App")
.controller("FloorController", function($state, $scope) {
    
});
