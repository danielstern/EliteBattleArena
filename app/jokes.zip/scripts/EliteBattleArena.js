angular.module("EliteBattleArena", [
    'EliteBattleArena.AI',
    'EliteBattleArena.Actor',
    'EliteBattleArena.App',
    'EliteBattleArena.Battle',
    'EliteBattleArena.Game',
    'EliteBattleArena.Helpers'])

